/**
 * 
 */
/**
 * 
 */
module MasterMind
{
}