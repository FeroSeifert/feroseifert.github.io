package masterMind;

import java.util.Random;
import java.util.Scanner;

public class MasterMindv2 {
	public static void main(String[] args) {

		Random rmd = new Random();
		Scanner sc = new Scanner(System.in);

		String[] colors = { "Red", "Orange", "Yellow", "Green", "Blue", "Purple" };
		String[] secret = new String[4];

		System.out
				.println("Welcome to MasterMind, choose game mode: 1 for Player vs. Computer, 2 for Player vs. Player");
		int choice = sc.nextInt();

		if (choice == 1) {

			System.out.println("Welcome to MasterMind Player vs. Computer mode!");

			// Generation of secret code
			for (int i = 0; i < 4; i++) {
				int rng = rmd.nextInt(6);
				String color = colors[rng];
				secret[i] = color;
			}

			// Attempts check
			int attempts = 0;
			boolean won = false;

			while (attempts < 10 && !won) {

				// Code guess
				String[] guess = new String[4];
				System.out.println("\nAttempt " + (attempts + 1)
						+ " Choose 4 colors, 1 at a time.  Colors available: Red, Orange, Yellow, Green, Blue, Purple");

				for (int i = 0; i < 4; i++) {
					guess[i] = sc.next();
				}

				// Feedback for colors
				System.out.println("\nFeedback for each color:");
				for (int i = 0; i < 4; i++) {
					if (guess[i].equalsIgnoreCase(secret[i])) {

						System.out.println("Pin " + (i + 1) + ": Black");
					} else {
						boolean found = false;
						for (int j = 0; j < 4; j++) {
							if (i != j && guess[i].equalsIgnoreCase(secret[j]))

							{
								found = true;
								break;

							}

						}
						if (found) {
							System.out.println("Pin " + (i + 1) + ": White");
						} else {
							System.out.println("Pin " + (i + 1) + ": Nothing");
						}

					}

				}

				// Win check
				int correctCount = 0;
				for (int i = 0; i < 4; i++) {
					if (guess[i].equalsIgnoreCase(secret[i])) {
						correctCount++;
					}

				}
				if (correctCount == 4) {
					won = true;
					System.out.println("\nCongratulations! You cracked the code!");
				}

				attempts++;
			}

			if (!won) {
				System.out.println("\nYou've used all attempts, loser!");
				System.out.println("The code was");
				for (int i = 0; i < secret.length; i++) {
					System.out.print(secret[i] + " ");
				}

			}

		} else if (choice == 2) {

			System.out.println("Welcome to MasterMind Player vs. Player mode");

			// Generation of secret code player mode
			System.out.println("\nPlayer 1: Enter your secret code (4 colors, one at a time):");
			for (int i = 0; i < 4; i++) {
				secret[i] = sc.next();
			}

			// Clear screen so Player 2 cannot see
			for (int i = 0; i < 100; i++) {
				System.out.println();
			}

			System.out.println("Player 2: Now it's your turn");

			// Attempts check
			int attempts = 0;
			boolean won = false;

			while (attempts < 10 && !won) {

				// Code guess
				String[] guess = new String[4];
				System.out.println("\nAttempt " + (attempts + 1)
						+ " Choose 4 colors, 1 at a time. Colors available: Red, Orange, Yellow, Green, Blue, Purple");

				for (int i = 0; i < 4; i++) {
					guess[i] = sc.next();
				}

				// Feedback for colors
				System.out.println("\nFeedback for each color:");
				for (int i = 0; i < 4; i++) {
					if (guess[i].equalsIgnoreCase(secret[i])) {

						System.out.println("Pin " + (i + 1) + ": Black");
					} else {
						boolean found = false;
						for (int j = 0; j < 4; j++) {
							if (i != j && guess[i].equalsIgnoreCase(secret[j]))

							{
								found = true;
								break;

							}

						}
						if (found) {
							System.out.println("Pin " + (i + 1) + ": White");
						} else {
							System.out.println("Pin " + (i + 1) + ": Nothing");
						}

					}

				}

				// Win check
				int correctCount = 0;
				for (int i = 0; i < 4; i++) {
					if (guess[i].equalsIgnoreCase(secret[i])) {
						correctCount++;
					}

				}
				if (correctCount == 4) {
					won = true;
					System.out.println("\nCongratulations! You cracked the code!");
				}

				attempts++;
			}

			if (!won) {
				System.out.println("\nYou've used all attempts, loser!");
				System.out.println("\nPlayer 1 wins!");
				System.out.print("The code was: ");
				for (int i = 0; i < secret.length; i++) {
					System.out.print(secret[i] + " ");
				}

			}

		} else

			System.out.println("Invalid choice");

		sc.close();

	}

}